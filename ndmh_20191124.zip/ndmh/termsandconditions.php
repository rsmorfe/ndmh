<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
	<title>NDMH | Privacy Policy</title>
	<!-- Custom fonts for this template-->
  <!-- Custom fonts for this template-->
  <link href="dist/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="dist/css/sb-admin.css" rel="stylesheet">
</head>

<body>
<div class="container=fluid">
	<div class="container">
<a href="onlineappointment.php">
<img src="dist/img/dmh2.png" class="img img-fluid">
</a>
<br><br>
<h2>Privacy Policy</h2>

<p>Divine Mercy Hospital respects its patient’s right to privacy and everyone’s privacy of personal data.  We are committed to handling with care your personal data that are under our control.  You have the right to be informed how the hospital, collects and uses (including disclosure) your personal and health information.<br><br>
<b>What personal data do we collect from you?</b><br><br>
Our doctors, nurses, and other members of the healthcare team who are taking care of you may collect, document, use and store your personal information to ensure that you will be given the highest possible quality of patient care that you deserve. The following personal and health information may include the following:<br><br>
•	Basic personal information, such as but not limited to, your name, address, date of birth, gender, religious affiliation, contact information, occupation, marital status, citizenship.<br>
•	Relevant information and contact information of your relatives, guardians or next of kin.<br>
•	Chief complaint(s)<br>
•	Medical history such as, but not limited to, date of previous admissions, existing illness, medication intake, family medical history and sexual life.<br>
•	Vital signs (blood pressure, temperature, pulse rate, respiratory rate)<br>
•	Biometrics, such as height and weight; biological information such as blood type.<br>
•	Result of xrays, scans, laboratory tests and other diagnostic procedures.<br>
•	For business purposes: Philhealth details, Social Security System details, Government Insurance System details, and insurance details, Senior Citizen details, Person with Disability details, Pag-IBIG number (Home Development Mutual Fund) and Tax Identification Number<br>
•	Other information as necessary.<br><br>
Our hospital is equipped with CCTV cameras to help us ensure safety and security of the patients, clients, the employees and the building.<br><br>
<b>How and When do we collect your data?</b><br><br>
It is important that we collect accurate information about you in both electronic and paper based forms<br>
•	Before implementing the healthcare services you are availing.<br>
•	When you get in touch with us to ask about something, file a complaint or request for service.<br>
•	Take part of our research, surveys.<br>
•	Participate in various activities sponsored by us or any other organization acting on our behalf, such as symposia, conferences, focus group discussions and the like; and<br>
•	When you apply for a job with us.<br><br>
If you feel that some of the information we collect are not necessary, please feel free to ask any of our staff so that we can explain to you why the information are needed and requested from you.<br><br>
<b>Why do we collect personal data about you?</b><br><br>
•	For Medical Treatment: When providing patient care and medical treatment, we collect your personal data to help us understand your current health status and to assist us in maintaining a record of the care and other services that you have received from the hospital. We maintain your medical record for efficient coordination between members of the healthcare team who are involved in the management of your care. This will also allow continuity of care in case you return to us for follow ups and other healthcare services.  For this purpose, R.A. 10173 otherwise known as the Data Privacy Act of 2012 allows us to maintain these records.<br>
•	For Reporting Requirements: Information about certain diseases and other conditions may be reported to the Department of Health or other local and national government agencies, as mandated and authorized by laws and regulations. Your health information may also be disclosed to the Philippine Health Insurance Corporation (PhilHealth) as required by law.<br>
•	For Admission and Billing and Claims Processing: For the purpose of processing your hospital bills, your information may be used and disclosed to the Philippine Health Insurance Corporation (PhilHealth), social welfare agency, your insurance company, Health Maintenance Organizations (HMOs) and employer to facilitate reimbursement of the hospital bill.<br>
•	For Historical, Statistical or Scientific Purpose: Your information may be used to generate data that would help the hospital enhance its services.<br>
•	For Business Operations: Your personal information will be processed as part of our hospital operations. This includes our general business management operations, quality control and assessment, employee and/or staff evaluation, training of medical students and residents and financial performance reporting.  Examples of these include the calling of your name verbally or through a prompter in a queue, our internal evaluation of employees and medical staff performance, giving access to your medical information to medical students and residents as part of our training programs, contacting you personally for appointments and follow ups, preparation of statistical data pertaining to the operations of the hospital for quality assurance and financial reporting.<br>
•	Performance of a legal obligation: Under the law, the Hospital is requires to share your personal information to government authorities in certain instances such as, we may be required to provide documentary and/or testimonial evidence in court proceedings that may require the disclosure of your personal information. We may also be required to provide your personal information to government authorities in certain circumstances.<br>
•	Marketing and other legitimate commercial purposes: We may also use your personal information to contact you with newsletters, updates, information campaigns, marketing promotional materials and other information that may be related to the services we provide.<br><br>
Other uses and disclosures of your personal information<br>
Outside of the purposes stated above other uses and disclosures of your personal information be made only with your express authorization, unless we are otherwise permitted or required by law.  Your personal information may be used and disclosed by the hospital in the following circumstances.<br>
•	Access to patient directory by your visitors.<br>
•	Other people involved in, or interested in your healthcare, such as your family members, loved ones or any other person you identify as being involved in your healthcare. In case you are not capable of agreeing or objecting, we will use our judgement in determining whether the use or disclosures is in your best interest. Except in case of an emergency or when otherwise permitted or required by law, we will inform you of our intended action prior to making such use or disclosure and will, at that time, offer you the opportunity to object.  If you are not present or unable to agree or object, we will use our judgement in determining whether the use or disclosures is in your best interest.  We may also use or disclose your personal information without your consent or authorization when such use or disclosure is required by law.  This includes the disclosure of your personal information pursuant to an order of a court of tribunal, or when such disclosure is required under existing laws and regulations.<br><br>
<b>Do we share your personal data to other institution or organization?</b><br><br>
Yes.  There are instances that we share your personal data to government agencies which lawfully collects information.  For instance, the Department of Health requires submission of relevant personal information of patients with certain non-communicable and communicable disease, injuries, etc. for purposes of disease surveillance and monitoring.<br>
We may also share personal information to fulfil legal mandate/s like when ordered lawfully to do so by a court or a government agency or public authority.<br>
We may also share personal information with our service providers, partners, affiliates and related entities who provide products and services to the hospital for the same purpose as explained above.<br><br>
 
<b>How long do we secure your personal data? How long will we keep your data?</b><br><br>
Only authorized personnel have access to your personal information in our files.
We have set-up adequate, technical, physical, and organizational security measures to protect your data from unauthorized access and disclosure.<br>
We store your personal data in accordance with period guidelines and limitations provided by governing agencies, such as, Department of Health for retention of medical records and Bureau of Internal Revenue for financial documents.  We will take reasonable steps in disposing or discarding your personal information in a secure manner that would prevent further processing, unauthorized access, or disclosure to any other party or the public, or prejudice your rights as a data subject.<br><br>
<b>What are your Rights as data subject?</b><br><br>
•	You have the right to request a copy of personal and health information that we hold about you, as well as to ask for it to be corrected if you think there is anything wrong.<br>
•	You have the right to object to, or withdraw consent that may have been given for, certain processing like direct marketing, trainings and researches.<br>
•	You have the right to suspend, withdraw, or order blocking, removal or destruction of your personal data from our filing system if you have substantial proof that your rights are violated or that your data are incomplete, false or unlawfully obtained; or processed for unauthorized or unlawful purpose.<br>
•	You have the right to be indemnified for damages you may sustained due to inaccurate, incomplete, false or unauthorized use of your personal data.<br>
•	Transmissibility of your Rights. Upon death or incapacity, your rights may be transferred to your lawful heirs.<br><br>
<b>How can you contact us?</b><br><br>
If you have complaints or questions, you may direct your concerns to the hospital admitting office at (632)808-3392/93 local 104 or email us at info@newdivinemercyhospital.com.ph.<br><br>
If you think your concerns are not acted upon, please email us, attention: Data Privacy Officer.<br>
In case we are unable to address your concern, you have the right to lodge your complaint before the National Privacy Commission.<br><br>
<b>Website Privacy Policy</b><br><br>
This Section is applicable to the website and affiliate sites of Divine Mercy Hospital.  Please be advised that practices described in this Privacy Policy apply only to information gathered online at our website.<br><br>
By visiting our website, you are accepting these terms.  If you do not agree to the terms of this Privacy Policy, please do not use the website.<br><br>
By downloading images found in our website, you are voluntarily giving to us your email address.  This data is stored in our database for security monitoring and not for marketing or non-medical purposes.<br><br>
Divine Mercy Hospital website, and its auxiliary sites, use website cookies.  These are only used to enhance the usability of our webpage.  We do not store any personal information on our website or database<br><br>
Website Data Security:  Our website is a highly secured website.  We ensure that all users visiting this site have their confidential data protected from phishers and unauthorized personnel.<br><br>
Rest assured that data are located on our highly secured database.<br>
Links to other websites:  Our official website contains links or external links that are/may be related to the organization, doctors, health education, news and hospital events/activities.<br><br>
These websites have their own privacy policies and not covered by us.<br><br>

 
<b>Access and Correction</b><br><br>
You have the right to access, modify and delete your Personal Information or raise questions or concern by contacting us through our HR Department (632) 808-3392-93 local 113.<br><br>
If you think your rights are violated or not acted upon, you may email our Data Privacy Officer at info@newdivinemercyhospital.com.ph.<br><br>
In the event that Divine Mercy Hospital is unable to address your privacy concerns, you may lodge your complaint before the National Privacy Commission.<br><br>
Our undertakings regarding your personal information<br><br>
Pursuant to the Data Privacy Act (DPA), we undertake to protect your personal information.  The Hospital creates and maintains a record of your personal information in its offices and this notice applies to your personal information that we collect. Under the DPA, the Hospital is required to protect your personal information, and to process the same only in accordance with the following data privacy principles:<br><br>
•	Transparency: We are obliged to inform you of the nature, purpose and extent of our processing of your personal information, including the risks and safeguards involved, the identity of the persons involved in the processing of your personal data, your rights as data subject, and how these rights can be exercised.<br><br>
•	Legitimate purpose: We will only process your personal information for a legitimate purpose, compatible with our declared and specified purpose, and not contrary to law3, morals and public policy.<br><br>
•	Proportionality: We will process your personal information as adequate, relevant, suitable, necessary and not excessive in relation to the declared and specific purpose.<br>
Your personal information is stored in a manner that is reasonably protected from misuse and loss and from unauthorized access, modification and disclosure.  We strictly enforce our privacy policy and put in place technical, organizational and physical security measures that are designed to protect your personal information from unauthorized access, alteration and disclosure.<br><br>
When your personal information is no longer needed for which it was obtained, we will take reasonable steps in disposing or discarding your personal information in a secure manner that would prevent further processing, unauthorized access, or disclosure to any other party or the public, or prejudice your rights as a data subject.<br><br>
Changes to this Privacy Statement and Privacy Policy<br><br>
From time to time, we may change or update our privacy statement, privacy policy and practices to comply with government and regulatory requirements, to adapt to new technologies and protocols, to align with industry practices or for other legitimate purposes.<br><br>
Notice of significant changes will be posted in our website.  If we are required by law, we will take steps to obtain your updated consent.<br>
</p>
</div>
</div>





<script type="text/javascript">
	 <script src="dist/vendor/jquery/jquery.min.js"></script>
  <script src="dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="dist/vendor/jquery-easing/jquery.easing.min.js"></script>
</script>

</body>
</html>

