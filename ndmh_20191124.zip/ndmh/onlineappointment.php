<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>NDMH - Online Appointment Page</title>

  <!-- Bootstrap CSS-->
  <link href="dist/css/bootstrap.css" rel="stylesheet">

  <!-- Custom fonts for this template-->
  <link href="dist/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="dist/css/sb-admin.css" rel="stylesheet">

  <!-- DateTimePicker CSS-->
  <link href="dist/css/bootstrap-datetimepicker.min.css" rel="stylesheet">

</head>

<body class="img img-fluid hold-transition login-page" style="background-image: url('dist/img/img.jpg');  background-repeat: no-repeat; background-size: cover; filter: alpha(opacity=50) ">

  <div class="container"><br><br>
    <center>
    <div class="login-box">
      <div class="login-logo">
        <img src="dist/img/logo.png" class="img img-fluid" style="width: 10%"><br><br>
         <h4 style="color:#ffffff">ONLINE APPOINTMENT FORM</h4>
      </div>
      </center>
    </div>
    <div class="card card-register mx-auto mt-5">
      <div class="card-body">
        <form action="processappointment.php" method="post">
          <div class="form-group has-feedback">
            <input type="text" class="form-control" placeholder="First Name" name="online_fname" autocomplete="off" required>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="text" class="form-control" placeholder="Surname" name="online_lname" autocomplete="off"  required>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="text" class="form-control" placeholder="Concern" name="online_concern"  autocomplete="off" required>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            <h6 style="font-size: 12px; color: red;">*Provides us a brief explanation of what your main concern is for the awareness of the doctor.</h6>
          </div>
          <div class="form-group has-feedback">
            <select class="form-control"   name="online_schedule"  id="doc_schedule" autocomplete="off" required>
              <option value="" disabled selected style="display:none;"></option>
              <?php
                include('dist/includes/dbcon.php');
      
                if (!$conn) {
                  die("Connection failed: " . mysqli_connect_error());
                }

                $sql = "SELECT id,(select specialty from doctors where dr_id = DoctorID) as Specialty,(select concat(first_name,' ',last_name) from doctors where dr_id = DoctorID) as Doctor,concat(ConsultationStart,' - ',ConsultationEnd) as Schedule,ConsultationDays FROM roomschedule";
                $results = mysqli_query($conn, $sql);
    
                while($result = mysqli_fetch_assoc($results)){  //fetching the result (iteration)
                  echo '<option value='.$result[id].'>['.$result[Specialty].'] - '.$result[Doctor].' ('.$result[ConsultationDays].' - '.$result[Schedule].')'.'</option>';
                }             
              ?>
            </select>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>

          <div class="input-group date mb-2" id='datetimepicker3'>
            <input type='text' placeholder="Select Appointment Date" class="form-control" name="appointment_date" id="appointment_date" required/>&nbsp    
            <span id="clock_icon" class="input-group-addon btn btn-secondary">
                <span class="fa fa-clock"></span>
            </span>
          </div>

          <div class="row">
            <input type="checkbox" class="d-block small mt-2 ml-3 mb-3" name="accept_terms" value="yes" required>&nbsp I have fully accepted the Terms and Conditions, as stated&nbsp<a class="d-block" href="termsandconditions.php">here.</a>
            <button type="reset" class="btn btn-block btn-flat">Clear Fields</button>
            <button type="submit" class="btn btn-primary btn-block btn-flat ml-3 mr-3" name="register" default>Submit</button>
          </div><!-- /.col -->
        
        </form>

      </div>
    </div>
  </div>
<br>
        <br>
        <br>
  <!-- Bootstrap core JavaScript-->
  <script src="dist/vendor/jquery/jquery.js"></script>
  <script src="dist/js/moment.js"></script>
  <script src="dist/js/transition.js"></script>
  <script src="dist/js/collapse.js"></script>
  <script src="dist/vendor/jquery/jquery.min.js"></script>
  <script src="dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="dist/vendor/bootstrap/js/bootstrap.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="dist/vendor/jquery-easing/jquery.easing.js"></script>

  <!-- Custom scripts h6 all pages-->
  <script src="dist/js/sb-admin.min.js"></script>

  <!-- DateTimePicker-->
  <script src="dist/js/bootstrap-datetimepicker.js"></script>


  <script type="text/javascript">
  function DisabledDays (sched) {
    var setDays;

    switch (sched) {
      case "MW":
        // 0 = SUNDAY, 6 = SATURDAY
        setDays = [0,2,4,5,6];
        break;
      case "TTH":
        setDays = [0,1,3,5,6];
        break;
      case "FS":
        setDays = [0,1,2,3,4];
        break;
      case "Friday":
        setDays = [0,1,2,3,4,6];
        break;
      case "SATSUN":
        setDays = [1,2,3,4,5];
        break;
    }

    return setDays;
  }

  $(document.body).on('change','#doc_schedule', function (e) { 


    document.getElementById("appointment_date").value = "Select Appointment Date2";


    var getSchedule = $('#doc_schedule option:selected').text() // RETRIEVE VALUR FROM SELECTED
    // GETS THE SUBSTRING FROM OPENING TO CLOSING PARENTHESIS
    getSchedule = getSchedule.substr(getSchedule.indexOf('(') + 1,(getSchedule.indexOf(')')))
    // GETS THE ACTUAL SCHEDULE (DAYS)
    getSchedule = getSchedule.substr(0,(getSchedule.indexOf(' -'))) 

    var DaysDisabled = DisabledDays(getSchedule);

    $('#datetimepicker3').datetimepicker.destroy;

    var dateToday = new Date();

    $('#datetimepicker3').datetimepicker({
      format: 'YYYY-MM-DD',
      minDate: dateToday
    });

    var dp = $('#datetimepicker3').data('DateTimePicker');
    dp.minDate(dateToday);
    dp.daysOfWeekDisabled(DaysDisabled);
  });
  </script>
</body>

</html>
