<?php

include('../dist/includes/dbcon.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT Date(DateCreated) as date FROM queueing WHERE Date(DateCreated) < date(NOW()) group by DateCreated";
$results = mysqli_query($conn, $sql);

    if(mysqli_num_rows($results) >0){ //if the query return a row
        // DELETE all records
        $sql = "DELETE FROM queueing";
        mysqli_query($conn, $sql);

        //ALTER queueing table auto_increment
        $sql = "ALTER TABLE queueing AUTO_INCREMENT = 1";
        mysqli_query($conn, $sql);
    }
?>