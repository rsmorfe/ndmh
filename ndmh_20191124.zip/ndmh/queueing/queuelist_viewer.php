<?php 
  session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>NDMH | QUEUE SYSTEM</title>

  <!-- Custom fonts for this template-->
  <link href="../dist/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="../dist/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../dist/css/sb-admin.css" rel="stylesheet">

</head>

<body>
<body id="page-top">

  <!-- HEADER -->
  <nav class="navbar navbar-expand-xl navbar-dark bg-dark static-top justify-content-center align-items-center">
    <a class="navbar-brand text-center"  href="queuelist_viewer.php">New Divine Mercy Hospital</a>
  </nav>

  <div id="wrapper">
  
  <div class="sidebar col-lg-4 text-white">
    <table class="text-white h3 mt-3" id="queue_table" width="100%" cellspacing="0" cellpadding="20"> 
    <!-- Sidebar -->
    
    </table>
  </div>
    


    <div id="content-wrapper">
      <!-- Advertisments -->
      <div class="container-fluid">

      </div>

        
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer col-lg-8">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © New Divine Mercy Hospital - OPD 2019</span>
          </div>
        </div>
      </footer>

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

<!-- Bootstrap core JavaScript-->
<script src="../dist/vendor/jquery/jquery.min.js"></script>
<script src="../dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="../dist/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Chart JS-->
<script src="../dist/vendor/chart.js/Chart.bundle.js"></script>

<!-- Custom scripts for all pages-->
<script src="../dist/js/sb-admin.min.js"></script>

<script>
$(document).ready(function(){
  refreshTable();
});

function refreshTable(){
    $('#queue_table').load('queuelist_load.php', function(){
       setTimeout(refreshTable, 1000);
    });
}
</script>


</body>
</html>