<?php

    include('../dist/includes/dbcon.php');

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "SELECT MIN(qid) as qid,assignedRoom as Room FROM queueing GROUP BY assignedRoom";
    $results = mysqli_query($conn, $sql);

    if(mysqli_num_rows($results) >0){ //if the query return a row
        echo "<thead> <tr><th class='text-center'>ROOM</th><th class='text-center'>SERVING</th></tr>"; //record found
        while($result = mysqli_fetch_assoc($results)){  //fetching the result (iteration)
            echo '<tr><td class="text-center">'. $result['Room']. '</td><td class="text-center text-warning">'. $result['qid'].'</td>';
            echo'</tr>';
        }
    
    }else{
        //no record found
        //echo "Record Not Found";
    }
?>