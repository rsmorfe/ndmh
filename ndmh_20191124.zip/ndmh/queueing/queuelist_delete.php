<?php

include('../dist/includes/dbcon.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['AssignedRoom'])){

    $conn = mysqli_connect('localhost','root',''); //connect to the mysql server 
    mysqli_select_db($conn,'ndmh'); //select database to work with 
      
    $assigned_room = mysqli_real_escape_string($conn,$_POST['AssignedRoom']);  
    
    $sql = "DELETE FROM queueing WHERE assignedRoom = '$assigned_room' order by qid ASC LIMIT 1";
   
    $execute = mysqli_query($conn,$sql);
    
    if(mysqli_errno($conn) > 0 ){
        echo "<script type='text/javascript'>alert('Error !!!');</script>";     
    }else{
        //echo "<script type='text/javascript'>alert('Successfully Added!');</script>";
    }
  
}
?>