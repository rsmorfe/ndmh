<?php session_start();
if(empty($_SESSION['id'])):
header('../index.php');
endif;

include('../dist/includes/dbcon.php'); 
mysqli_select_db($conn,'ndmh'); //select database to work with 

$patient_id = mysqli_real_escape_string($conn,$_POST['patient_id']); 
$patient_first = mysqli_real_escape_string($conn,$_POST['patient_first']); 
$patient_last = mysqli_real_escape_string($conn,$_POST['patient_last']); 
$gender = mysqli_real_escape_string($conn,$_POST['gender']); 
$birthdate = mysqli_real_escape_string($conn,$_POST['birthdate']);  
$contactno = mysqli_real_escape_string($conn,$_POST['contactno']);     

$sql = "UPDATE patients SET patient_first = '$patient_first',patient_last = '$patient_last',birthdate = '$birthdate',age = '$age',contactno = '$contactno' WHERE id = '$patient_id'";

$execute = mysqli_query($conn,$sql) or mysqli_errno($conn);

if(mysqli_errno($conn) > 0 ){
 echo "<script type='text/javascript'>alert('Error !!!');</script>";    
}else{
  echo "<script type='text/javascript'>alert('Successfully Added!');</script>";

  if($_SESSION['status'] == 'administrator') {
    echo "<script>document.location='patient_list.php'</script>"; 
  } elseif ($_SESSION['status'] == 'NurseStation') {
    echo "<script>document.location='patient_list2.php'</script>"; 
  } 

  
}

	
?>
