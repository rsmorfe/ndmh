<?php session_start();
if(empty($_SESSION['id'])):
header('../index.php');
endif;

include('../dist/includes/dbcon.php'); 
mysqli_select_db($conn,'ndmh'); //select database to work with 

// get record form walk-in table
$oid = htmlspecialchars($_GET['id']);
$sql = "SELECT * FROM queuelist_online where ol_id = '$oid'";
$results = mysqli_query($conn, $sql);
$result = mysqli_fetch_assoc($results);

$id = "ol-".$result['ol_id']; 
$fname = $result['fname']; 
$lname = $result['lname']; 
$concern = $result['concern']; 
$schedID = $result['schedID']; 

// CHECK IF SCHEDULE OF EACH DOCTOR HAS 30 queued patients
$sql = "SELECT COUNT(schedID) as RowCount FROM queuelist_active WHERE schedID = '$schedID' AND RecordStatus = 0";
$results = mysqli_query($conn, $sql);
$result = mysqli_fetch_assoc($results);
if($result['RowCount'] == 30){
  echo "<script type='text/javascript'>alert('Unable to Process. Slots for selected schedule are currently full.');</script>";
    echo "<script>document.location='scheduler_online.php'</script>";
}else{
  // insert record to active queue table
  $sql = "INSERT INTO queuelist_active(ref_qid,fname,lname,concern,schedID) VALUES('$id','$fname','$lname','$concern','$schedID')";
  $execute = mysqli_query($conn,$sql) or mysqli_errno($conn);

  if(mysqli_errno($conn) > 0 ){
  echo "<script type='text/javascript'>alert('Error !!!');</script>";    
  }else{
  echo "<script type='text/javascript'>alert('Successfully Added!');</script>";

  // remove record from walk-in table
  $sql = "DELETE FROM queuelist_online where ol_id = '$oid'";
  $execute = mysqli_query($conn,$sql) or mysqli_errno($conn);

  if($_SESSION['status'] == 'administrator') {
    echo "<script>document.location='patient_schedule.php'</script>"; 
  } elseif ($_SESSION['status'] == 'NurseStation') {
    echo "<script>document.location='nurse_view.php'</script>"; 
  } 
  
  }
}

	
?>
