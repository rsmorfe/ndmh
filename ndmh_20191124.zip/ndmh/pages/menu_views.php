<a class="dropdown-item" href="accounts.php">Accounts</a>
<a class="dropdown-item" href="view_roomschedule.php">Room Schedules</a>
<a class="dropdown-item" href="patient_list.php">Patient List</a>
<a class="dropdown-item" href="patient_schedule.php">Patient Scheduler</a>