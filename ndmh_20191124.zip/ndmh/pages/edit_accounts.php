<?php session_start();

if($_SESSION['loggedIn'] != 'yes'){
header('Location:../index.php');}?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>NDMH | ADD ACCOUNTS</title>

  <!-- Custom fonts for this template-->
  <link href="../dist/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="../dist/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../dist/css/sb-admin.css" rel="stylesheet">

</head>
<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <a class="navbar-brand mr-1" href="dashboard.php">NDMH ADMIN PAGE</a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>


    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0">
      
    <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span>Welcome, &nbsp</span>
           <?php echo $_SESSION['member_first']; ?>&nbsp<?php echo $_SESSION['member_last']; ?> &nbsp [<?php echo $_SESSION['status']; ?>] &nbsp
          <i class="fas fa-user-circle"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
      </li>
    </ul>

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <!-- Main Transaction Forms -->
        <?php 
          include('menu_transaction.php');
        ?>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <!-- Viewing Forms -->
          <?php 
            include('menu_views.php');
          ?>
        </div>
      </li>
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            &nbspAdd Accounts
          </div>
          <div class="card-body">
          
          </div>
        </div>
        
<?php 

  $conn = mysqli_connect('localhost','root',''); //connect to the mysql server 
  mysqli_select_db($conn,'ndmh'); //select database to work with 

  
  $id = $_GET['id'];
  $query=mysqli_query($conn,"SELECT * from member where member_id='$id'")or die(mysqli_error($conn));
  $result1 = mysqli_fetch_assoc($query);
?>

    <h1>TESTING NG SYSTEM</h1>
  <form method="post" action="update.php">
    <input class="form-control" type="text" class="form-control" name="id" VALUE="<?PHP ECHO htmlentities($id); ?>"required readonly> <br>
    <label for="">member first name</label><br>
    <input class="form-control" type="text" name="member_first" value="<?php echo htmlentities($result1['member_first']);?>" required><br>

    <label for="">member last name</label><br>
    <input class="form-control" type="text" name="member_last" value="<?php echo htmlentities($result1['member_last']);?>" required><br><br>

    <label for="">member rank</label><br>
    <input class="form-control" type="text" name="member_rank" value="<?php echo htmlentities($result1['member_rank']);?>" required><br><br>

    <label for="">Dept Code</label><br>
    <input class="form-control" type="text" name="dept_code" value="<?php echo htmlentities($result1['dept_code']);?>" required><br><br>

    <label for="">Username</label><br>
    <input class="form-control" type="text" name="username" value="<?php echo htmlentities($result1['username']);?>" required><br><br>

    <label for="">Password</label><br>
    <input class="form-control" type="text" name="password" required><br><br>

    <label for="">Status</label><br>
    <input class="form-control" type="text" name="status" value="<?php echo htmlentities($result1['status']);?>" required><br><br>



    <input class="form-control" type="submit" name="save" value="UPDATE">
  </form>
  </center>
      </div>

        
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © New Divine Mercy Hospital - OPD 2019</span>
          </div>
        </div>
      </footer>

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript-->
  <script src="../dist/vendor/jquery/jquery.min.js"></script>
  <script src="../dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../dist/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts h6 all pages-->
  <script src="../dist/js/sb-admin.min.js"></script>

</body>

</html>
