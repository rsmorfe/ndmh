<a class="dropdown-item" href="add_doctor.php">Add Doctor</a>
<a class="dropdown-item" href="add_patient.php">Add Patients</a>
<a class="dropdown-item" href="add_accounts.php">Add Accounts</a>
<a class="dropdown-item" href="add_roomschedule.php">Add Schedule</a>