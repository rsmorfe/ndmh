<?php

$doc_fname = $_SESSION['member_first'];
$doc_lname = $_SESSION['member_last'];

$sql = "SELECT dr_id from doctors WHERE first_name = '$doc_fname' AND last_name = '$doc_lname'";

$results = mysqli_query($conn, $sql);

$result = mysqli_fetch_assoc($results);

$doctor_id = $result['dr_id'];

//echo "<script type='text/javascript'>alert('".$doctor_id."');</script>";
?>