<a class="dropdown-item" href="view_roomschedule2.php">Room Schedules</a>
<a class="dropdown-item" href="patient_list2.php">Patient List</a>
<a class="dropdown-item" href="../queueing/queuelist_console.php" target="_blank">Queue Controller</a>
<a class="dropdown-item" href="../queueing/queuelist_viewer.php" target="_blank">Queue Viewer</a>
