<?php session_start();

include('../dist/includes/dbcon.php');

if($_SESSION['loggedIn'] != 'yes'){
header('Location:../index.php');}?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>NDMH | ADD PATIENT RECORD</title>

  <!-- Bootstrap CSS-->
  <link href="../dist/css/bootstrap.css" rel="stylesheet">

  <!-- Custom fonts for this template-->
  <link href="../dist/vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="../dist/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../dist/css/sb-admin.css" rel="stylesheet">

</head>
<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <?php 
      if($_SESSION['status'] == 'administrator') {
        echo '<a class="navbar-brand mr-1" href="dashboard.php">NDMH ADMIN PAGE</a>';
      } elseif ($_SESSION['status'] == 'NurseStation') {
        echo '<a class="navbar-brand mr-1" href="nurse_view.php">NDMH PAGE</a>';
      } elseif ($_SESSION['status'] == 'Doctor') {
        echo '<a class="navbar-brand mr-1" href="doctor_view.php">NDMH PAGE</a>';
      }
    ?>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>


    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0">
      
    <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span>Welcome, &nbsp</span>
           <?php echo $_SESSION['member_first']; ?>&nbsp<?php echo $_SESSION['member_last']; ?> &nbsp [<?php echo $_SESSION['status']; ?>] &nbsp
          <i class="fas fa-user-circle"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
      </li>
    </ul>

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item">
        <?php
          if ($_SESSION['status'] == 'administrator') {
            echo '<a class="nav-link" href="dashboard.php">';
          } elseif ($_SESSION['status'] == 'NurseStation') {
            echo '<a class="nav-link" href="nurse_view.php">';
          } 
        ?>
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <?php
        if ($_SESSION['status'] == 'NurseStation') {
          echo '<li class="nav-item">';
          echo '<a class="nav-link" href="doctor_list2.php">';
          echo '<i class="fas fa-fw fa-user-alt"></i>';
          echo '<span> Doctors List</span></a></li>';
        } 
      ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <!-- Main Transaction Forms -->
        <?php 
          if ($_SESSION['status'] == 'administrator') {
            include('menu_transaction.php');
          } elseif ($_SESSION['status'] == 'NurseStation') {
            include('menu_transaction2.php');
          } 
          
        ?>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <!-- Viewing Forms -->
          <?php 
            if($_SESSION['status'] == 'administrator') {
              include('menu_views.php');
            } elseif ($_SESSION['status'] == 'NurseStation') {
              include('menu_views2.php');
            } 
          ?>
        </div>
      </li>
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            &nbspAdd Patient Record
          </div>
          <div class="card-body">
          <?php 
  if(isset($_POST['add_patientrec'])){

    $conn = mysqli_connect('localhost','root',''); //connect to the mysql server 
    mysqli_select_db($conn,'ndmh'); //select database to work with 

    $qid = mysqli_real_escape_string($conn,$_POST['qid']); // for updating queue list record status

    $patient_id   = mysqli_real_escape_string($conn,$_POST['patient_id']); 
    $doctor_id = mysqli_real_escape_string($conn,$_POST['doctor_id']); 
    $findings   = mysqli_real_escape_string($conn,$_POST['findings']); 
    $recommendations = mysqli_real_escape_string($conn,$_POST['recommendations']);     
    
    $sql = "INSERT INTO patient_history(pid,docid,findings,recommendations) VALUES('$patient_id','$doctor_id','$findings','$recommendations')";

    $execute = mysqli_query($conn,$sql);
    
    if(mysqli_errno($conn) > 0 ){
        echo "<script type='text/javascript'>alert('Error !!!');</script>";     
    }else{
        $sql = "UPDATE queuelist_active SET RecordStatus = 1 WHERE qid = '$qid'";

        $execute = mysqli_query($conn,$sql);
        echo "<script type='text/javascript'>alert('Successfully Added!');</script>";

        if($_SESSION['status'] == 'administrator') {
          echo "<script>document.location='patient_schedule.php'</script>";       
        } elseif ($_SESSION['status'] == 'NurseStation') {
          echo "<script>document.location='nurse_view.php'</script>";       
        } 

        
    }
  
  }
?>
  <form method="post">
    <input class="form-control" type="text" name="qid" autocomplete="off" value="<?php echo htmlentities($_GET['id']);?>"hidden><br>
    <h6>Patient</h6>
    <select class="form-control" name="patient_id" required>
      <?php

        $first = htmlspecialchars($_GET['first']);
        $last = htmlspecialchars($_GET['last']);
        $sql = "SELECT id,concat(patient_first,' ',patient_last) as PatientName from patients where patient_first = '$first' AND patient_last = '$last'";
        $results = mysqli_query($conn, $sql);

        while($result = mysqli_fetch_assoc($results)){
      ?>
      <option value="<?php echo htmlentities($result['id']);?>"><?php echo htmlentities($result["PatientName"]);?></option>
    <?php } ?>
    </select><br>

    <h6>Doctor</h6>
    <select class="form-control" name="doctor_id" required>
      <?php

        $schedID = htmlspecialchars($_GET['schedid']);
        $sql = "SELECT b.dr_id,CONCAT(b.first_name,' ',b.last_name) AS Doctor FROM roomschedule a INNER JOIN doctors b ON b.dr_id = a.DoctorID WHERE a.id = '$schedID'";
        $results = mysqli_query($conn, $sql);

        while($result = mysqli_fetch_assoc($results)){
      ?>
      <option value="<?php echo htmlentities($result['dr_id']);?>"><?php echo htmlentities($result["Doctor"]);?></option>
    <?php } ?>
    </select><br>

    <h6>Findings</h6>
    <input class="form-control" type="text" name="findings" autocomplete="off" required><br>

    <h6>Recommedations</h6>
    <input class="form-control" type="text" name="recommendations" autocomplete="off" required><br>

    <input type="submit" value="ADD" name="add_patientrec">
  </form>

          </div>
        </div>
 

      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © New Divine Mercy Hospital - OPD 2019</span>
          </div>
        </div>
      </footer>


    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript-->
  <script src="../dist/vendor/jquery/jquery.js"></script>
  <script src="../dist/js/moment.js"></script>
  <script src="../dist/js/transition.js"></script>
  <script src="../dist/js/collapse.js"></script>
  <script src="../dist/vendor/jquery/jquery.min.js"></script>
  <script src="../dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../dist/vendor/bootstrap/js/bootstrap.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../dist/vendor/jquery-easing/jquery.easing.js"></script>

  <!-- Custom scripts h6 all pages-->
  <script src="../dist/js/sb-admin.min.js"></script>

  
</body>

</html>
