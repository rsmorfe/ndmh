<?php session_start();

include('../dist/includes/dbcon.php');

if($_SESSION['loggedIn'] != 'yes'){
header('Location:../index.php');}?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>NDMH | Patient History</title>

  <!-- Custom fonts for this template-->
  <link href="../dist/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="../dist/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../dist/css/sb-admin.css" rel="stylesheet">

</head>
<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

     <?php 
      if($_SESSION['status'] == 'administrator') {
        echo '<a class="navbar-brand mr-1" href="dashboard.php">NDMH ADMIN PAGE</a>';
      } elseif ($_SESSION['status'] == 'NurseStation') {
        echo '<a class="navbar-brand mr-1" href="nurse_view.php">NDMH PAGE</a>';
      } elseif ($_SESSION['status'] == 'Doctor') {
        echo '<a class="navbar-brand mr-1" href="doctor_view.php">NDMH PAGE</a>';
      }
    ?>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>


    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0">
      
    <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span>Welcome, &nbsp</span>
           <?php echo $_SESSION['member_first']; ?>&nbsp<?php echo $_SESSION['member_last']; ?> &nbsp [<?php echo $_SESSION['status']; ?>] &nbsp
          <i class="fas fa-user-circle"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
      </li>
    </ul>

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item">
          <?php
            if ($_SESSION['status'] == 'administrator') {
              echo '<a class="nav-link" href="dashboard.php">';
            } elseif ($_SESSION['status'] == 'NurseStation') {
              echo '<a class="nav-link" href="nurse_view.php">';
            } 
          ?>
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <?php
        if ($_SESSION['status'] == 'NurseStation') {
          echo '<li class="nav-item">';
          echo '<a class="nav-link" href="doctor_list2.php">';
          echo '<i class="fas fa-fw fa-user-alt"></i>';
          echo '<span> Doctors List</span></a></li>';
        } 
      ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <!-- Main Transaction Forms -->
        <?php 
          if ($_SESSION['status'] == 'administrator') {
            include('menu_transaction.php');
          } elseif ($_SESSION['status'] == 'NurseStation') {
            include('menu_transaction2.php');
          } 
        ?>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <!-- Viewing Forms -->
          <?php 
            if($_SESSION['status'] == 'administrator') {
              include('menu_views.php');
            } elseif ($_SESSION['status'] == 'NurseStation') {
              include('menu_views2.php');
            } 
          ?>
        </div>
      </li>
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Patient History              
            </div>
          <div class="card-body">
            <div class="table">
                <!-- Patient Header Details -->
                <?php
                    // LOAD HEADER DETAILS
                    if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                      }
                      $pid = $_GET['id'];
                      $sql = "SELECT concat(patient_first,' ',patient_last) as Fullname,gender,year(now())-year(birthdate) as age,contactno FROM patients where id = '$pid'";

                      $results = mysqli_query($conn, $sql);
          
                      if(!$results){
                        //no record found
                        echo "Record Not Found";
                      }elseif(mysqli_num_rows($results) >0){ //if the query return a row
                        while($result = mysqli_fetch_assoc($results)){  //fetching the result (iteration)
                            echo "<table align='left' style='border: none;margin-right: 150px'><tr><td>Patient :</td><td><b>".$result['Fullname']."</b></td></tr><tr><td>Sex :</td><td><b>".$result['gender']."</b></td></tr>";
                            
                            echo "<table style='border: none;'><tr><td>age :</td><td><b>".$result['age']."</b></td></tr><tr><td>Contact No :</td><td><b>".$result['contactno']."</b></td></tr></table>";

                        }
            
                      }else{
                        echo "No Record/s found";
                      }

                ?>
            </div>
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <?php        
                // LOAD DATA TO TABLE
                  if (!$conn) {
                    die("Connection failed: " . mysqli_connect_error());
                  }
                  //$pid = $_GET['id'];
                  $sql = "SELECT id,(select concat(first_name,' ',last_name) from doctors where dr_id = docid) as Doctor,findings,recommendations,DateCreated FROM patient_history where pid = '$pid'";
                  $results = mysqli_query($conn, $sql);
      
                  if(!$results){
                    //no record found
                    echo "Record Not Found";
                  }elseif(mysqli_num_rows($results) >0){ //if the query return a row
                    echo "<thead> <tr><th>ID</th><th>Doctor</th><th>Findings</th><th>Recommendations</th><th>Date</th></tr>"; //record found
                    while($result = mysqli_fetch_assoc($results)){  //fetching the result (iteration)
                    echo '<tr><td>'. $result['id']. '</td><td>' . $result['Doctor']. '</td><td>' . $result['findings'].'</td><td>' . $result['recommendations'].'</td><td>' . $result['DateCreated'].'</td>';
                    }
        
                  }else{
                    echo "No Record/s found";
                  }

                ?>
</table>    
    </div>    
      </div>
          </div>

      </div>

        
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © New Divine Mercy Hospital - OPD 2019</span>
          </div>
        </div>
      </footer>

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript-->
  <script src="../dist/vendor/jquery/jquery.min.js"></script>
  <script src="../dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../dist/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Datatable Script-->
  <script src="../dist/vendor/datatables/jquery.dataTables.js"></script>
  <script src="../dist/vendor/datatables/dataTables.bootstrap4.js"></script>    

  <!-- Custom scripts for all pages-->
  <script src="../dist/js/sb-admin.min.js"></script>

</body>

</html>
