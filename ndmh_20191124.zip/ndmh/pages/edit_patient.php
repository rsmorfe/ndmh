<?php session_start();

include('../dist/includes/dbcon.php');

if($_SESSION['loggedIn'] != 'yes'){
header('Location:../index.php');}?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>NDMH | EDIT PATIENT</title>

  <!-- Custom fonts for this template-->
  <link href="../dist/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="../dist/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../dist/css/sb-admin.css" rel="stylesheet">

  <link href="../dist/css/bootstrap-datetimepicker.min.css" rel="stylesheet">

</head>
<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

     <?php 
      if($_SESSION['status'] == 'administrator') {
        echo '<a class="navbar-brand mr-1" href="dashboard.php">NDMH ADMIN PAGE</a>';
      } elseif ($_SESSION['status'] == 'NurseStation') {
        echo '<a class="navbar-brand mr-1" href="nurse_view.php">NDMH PAGE</a>';
      } elseif ($_SESSION['status'] == 'Doctor') {
        echo '<a class="navbar-brand mr-1" href="doctor_view.php">NDMH PAGE</a>';
      }
    ?>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>


    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0">
      
    <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span>Welcome, &nbsp</span>
           <?php echo $_SESSION['member_first']; ?>&nbsp<?php echo $_SESSION['member_last']; ?> &nbsp [<?php echo $_SESSION['status']; ?>] &nbsp
          <i class="fas fa-user-circle"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
      </li>
    </ul>

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item">
          <?php
            if ($_SESSION['status'] == 'administrator') {
              echo '<a class="nav-link" href="dashboard.php">';
            } elseif ($_SESSION['status'] == 'NurseStation') {
              echo '<a class="nav-link" href="nurse_view.php">';
            } 
          ?>
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <?php
        if ($_SESSION['status'] == 'NurseStation') {
          echo '<li class="nav-item">';
          echo '<a class="nav-link" href="doctor_list2.php">';
          echo '<i class="fas fa-fw fa-user-alt"></i>';
          echo '<span> Doctors List</span></a></li>';
        } 
      ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <!-- Main Transaction Forms -->
        <?php 
          if ($_SESSION['status'] == 'administrator') {
            include('menu_transaction.php');
          } elseif ($_SESSION['status'] == 'NurseStation') {
            include('menu_transaction2.php');
          } 
        ?>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <!-- Viewing Forms -->
          <?php 
            if($_SESSION['status'] == 'administrator') {
              include('menu_views.php');
            } elseif ($_SESSION['status'] == 'NurseStation') {
              include('menu_views2.php');
            } 
          ?>
        </div>
      </li>
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            &nbspEdit Patient
          </div>
          <div class="card-body">

  <form method="post" action="update_patient.php">
  <input class="form-control" type="text" name="patient_id" autocomplete="off" hidden value="<?php echo htmlentities($_GET['id']); ?>">

    <?php 

      $id = $_GET['id'];
      $sql1 = "SELECT * from patients where id= ".$id;
      $query = mysqli_query($conn, $sql1);
      $results = mysqli_fetch_assoc($query);
    ?>
    <h6>First Name</h6>
    <input class="form-control" type="text" name="patient_first" required autocomplete="off" value="<?php echo htmlentities($results['patient_first']);?>"><br><br>

    <h6>Last name</h6>
    <input class="form-control" type="text" name="patient_last" required autocomplete="off" value="<?php echo htmlentities($results['patient_last']);?>"><br><br>

    <h6>Sex</h6>
    <input class="form-control" type="text" name="gender" required autocomplete="off" maxlength="1" value="<?php echo htmlentities($results['gender']);?>"><br><br>

    <h6>Birthdate</h6>
    <div class="input-group date mb-2" id='datetimepicker3'>
            <input type='text' placeholder="Birthdate" class="form-control" name="birthdate" required/>&nbsp    
            <span class="input-group-addon btn btn-secondary">
                <span class="fa fa-clock"></span>
            </span>
          </div><br>

    <h6>Contact No</h6>
    <input class="form-control" type="text" name="contactno" maxlength="11" required autocomplete="off" value="<?php echo htmlentities($results['contactno']);?>"><br><br>

    <input type="submit" value="UPDATE">
  </form>
  </center>
          </div>
        </div>
        

      </div>

        
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © New Divine Mercy Hospital - OPD 2019</span>
          </div>
        </div>
      </footer>

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript-->
   <script src="../dist/js/moment.js"></script>
  <script src="../dist/js/transition.js"></script>
  <script src="../dist/js/collapse.js"></script>
  <script src="../dist/vendor/jquery/jquery.min.js"></script>
  <script src="../dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../dist/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts h6 all pages-->
  <script src="../dist/js/sb-admin.min.js"></script>

   <script src="../dist/js/bootstrap-datetimepicker.js"></script>


  <script type="text/javascript">
    $(function () {
        $('#datetimepicker3').datetimepicker({
            format: 'YYYY-MM-DD'
        });
    });
  </script>

</body>

</html>
