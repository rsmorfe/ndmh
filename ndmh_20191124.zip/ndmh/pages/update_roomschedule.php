<?php session_start();
if(empty($_SESSION['id'])):
header('../index.php');
endif;

	$conn = mysqli_connect('localhost','root',''); //connect to the mysql server 
	mysqli_select_db($conn,'ndmh');


	$sched_id   = mysqli_real_escape_string($conn,$_POST['sched_id']); 
	$sched_room   = mysqli_real_escape_string($conn,$_POST['sched_room']); 
    $sched_doctor = mysqli_real_escape_string($conn,$_POST['sched_doctor']); 
    $sched_days   = mysqli_real_escape_string($conn,$_POST['sched_days']); 
    $sched_time_from = mysqli_real_escape_string($conn,date( "H:i:s", strtotime($_POST['sched_time_from'])));  
    $sched_time_to   = mysqli_real_escape_string($conn,date( "H:i:s", strtotime($_POST['sched_time_to']))); 
    
    
    $sql = "UPDATE roomschedule SET RoomID = '$sched_room',DoctorID = '$sched_doctor',ConsultationDays = '$sched_days',ConsultationStart = '$sched_time_from',ConsultationEnd = '$sched_time_to' WHERE id = '$sched_id'";

    mysqli_query($conn,$sql) or die(mysqli_error());
	
	echo "<script type='text/javascript'>alert('Successfully updated member details!');</script>";

 
    if ($_SESSION['status'] == 'administrator') {
        echo "<script>document.location='view_roomschedule.php'</script>";
    } elseif ($_SESSION['status'] == 'NurseStation') {
        echo "<script>document.location='view_roomschedule2.php'</script>";
    } 

	
?>
