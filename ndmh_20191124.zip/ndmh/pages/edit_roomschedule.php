<?php session_start();

include('../dist/includes/dbcon.php');

if($_SESSION['loggedIn'] != 'yes'){
header('Location:../index.php');}

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>NDMH | EDIT ROOM SCHEDULE</title>

  <!-- Bootstrap CSS-->
  <link href="../dist/css/bootstrap.css" rel="stylesheet">

  <!-- Custom fonts for this template-->
  <link href="../dist/vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="../dist/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- DateTimePicker CSS-->
  <link href="../dist/css/bootstrap-datetimepicker.min.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../dist/css/sb-admin.css" rel="stylesheet">

</head>
<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <?php 
      if($_SESSION['status'] == 'administrator') {
        echo '<a class="navbar-brand mr-1" href="dashboard.php">NDMH ADMIN PAGE</a>';
      } elseif ($_SESSION['status'] == 'NurseStation') {
        echo '<a class="navbar-brand mr-1" href="nurse_view.php">NDMH PAGE</a>';
      } elseif ($_SESSION['status'] == 'Doctor') {
        echo '<a class="navbar-brand mr-1" href="doctor_view.php">NDMH PAGE</a>';
      }
    ?>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>


    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0">
      
    <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span>Welcome, &nbsp</span>
           <?php echo $_SESSION['member_first']; ?>&nbsp<?php echo $_SESSION['member_last']; ?> &nbsp [<?php echo $_SESSION['status']; ?>] &nbsp
          <i class="fas fa-user-circle"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
    </li>
    </ul>

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item">
        <?php
          if ($_SESSION['status'] == 'administrator') {
            echo '<a class="nav-link" href="dashboard.php">';
          } elseif ($_SESSION['status'] == 'NurseStation') {
            echo '<a class="nav-link" href="nurse_view.php">';
          } elseif ($_SESSION['status'] == 'Doctor') {
            echo '<a class="nav-link" href="doctor_view.php">';
          }
        ?>
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <?php
        if ($_SESSION['status'] == 'NurseStation') {
          echo '<li class="nav-item">';
          echo '<a class="nav-link" href="doctor_list2.php">';
          echo '<i class="fas fa-fw fa-user-alt"></i>';
          echo '<span> Doctors List</span></a></li>';
        } 
      ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <!-- Main Transaction Forms -->
        <?php 
          if ($_SESSION['status'] == 'administrator') {
            include('menu_transaction.php');
          } elseif ($_SESSION['status'] == 'NurseStation') {
            include('menu_transaction2.php');
          } 
        ?>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <!-- Viewing Forms -->
          <?php 
            if($_SESSION['status'] == 'administrator') {
              include('menu_views.php');
            } elseif ($_SESSION['status'] == 'NurseStation') {
              include('menu_views2.php');
            } elseif ($_SESSION['status'] == 'Doctor') {
              echo '<a class="dropdown-item" href="edit_roomschedule.php?id='.$_GET["id"].'">Update Schedule</a>';
            }
          ?>
        </div>
      </li>
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            &nbspEdit Room Schedule
          </div>
          <div class="card-body">

  <form method="post" action="update_roomschedule.php">
    <input class="form-control" type="text" name="sched_id" autocomplete="off" hidden value="<?php echo htmlentities($_GET['id']); ?>">

    <?php

      $id = $_GET['id'];

      if (($_SESSION['status'] == 'administrator') OR ($_SESSION['status'] == 'NurseStation')) {
        $sql1 = "SELECT * from roomschedule where id= ".$id;
      } elseif ($_SESSION['status'] == 'Doctor') {
        $sql1 = "SELECT * from roomschedule where DoctorID= ".$id;
      }

      $results1 = mysqli_query($conn, $sql1);
      $docID = '';
      while($result1 = mysqli_fetch_assoc($results1)){
    ?>
    <h6>Room </h6>
    <input class="form-control" type="text" name="sched_room" autocomplete="off" value="<?php echo htmlentities($result1['RoomID']);?>"><br>

    <h6>Doctor</h6>
    <select class="form-control" name="sched_doctor">
      <?php

        $sql2 = "SELECT dr_id,concat(first_name,' ',last_name) as DoctorName from doctors";
        $results2 = mysqli_query($conn, $sql2);

        while($result2 = mysqli_fetch_assoc($results2)){
      ?>
      <option value="<?php echo htmlentities($result2['dr_id']);?>" <?php if($result1['DoctorID'] == $result2['dr_id']) { echo 'selected';}?>><?php echo htmlentities($result2["DoctorName"]);?></option>
    <?php } ?>
    </select><br>
    

    <h6>Consultation Days</h6>
    <input class="form-control" type="text" name="sched_days" autocomplete="off" value="<?php echo htmlentities($result1['ConsultationDays']);?>"><br>

    <h6>Consultation Time (From)</h6>
    <div class='input-group date' id='datetimepicker3' >
        <input type='text' class="form-control" name="sched_time_from" value="<?php echo htmlentities($result1['ConsultationStart']);?>"/>    
          <span class="input-group-addon btn btn-secondary">
              <span class="fa fa-clock"></span>
          </span>
    </div><br>

    <h6>Consultation Time (To)</h6>
  
    <div class='input-group date' id='datetimepicker4' >
      <input type='text' class="form-control" name="sched_time_to" value="<?php echo htmlentities($result1['ConsultationEnd']);?>"/>    
        <span class="input-group-addon btn btn-secondary">
            <span class="fa fa-clock"></span>
        </span>
    </div><br>
  <?php } ?>
    <input class="btn btn-warning" type="submit" value="UPDATE" name="edit_roomsched">
    <?php
          if ($_SESSION['status'] == 'administrator') {
            echo '<a class="btn btn-secondary" href="view_roomschedule.php">Return</a>';
          } elseif ($_SESSION['status'] == 'NurseStation') {
            echo '<a class="btn btn-secondary" href="view_roomschedule2.php">Return</a>';
          } elseif ($_SESSION['status'] == 'Doctor') {
            echo '<a class="btn btn-secondary" href="doctor_view.php">Return</a>';
          }
        ?>
  </form> 

          </div>
        </div>
 

      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © New Divine Mercy Hospital - OPD 2019</span>
          </div>
        </div>
      </footer>


    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript-->
  <script src="../dist/vendor/jquery/jquery.js"></script>
  <script src="../dist/js/moment.js"></script>
  <script src="../dist/js/transition.js"></script>
  <script src="../dist/js/collapse.js"></script>
  <script src="../dist/vendor/jquery/jquery.min.js"></script>
  <script src="../dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../dist/vendor/bootstrap/js/bootstrap.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../dist/vendor/jquery-easing/jquery.easing.js"></script>

  <!-- Custom scripts h6 all pages-->
  <script src="../dist/js/sb-admin.min.js"></script>

  <!-- DateTimePicker-->
  <script src="../dist/js/bootstrap-datetimepicker.js"></script>
  
  
  
  <script type="text/javascript">
    $(function () {
        $('#datetimepicker3').datetimepicker({
            format: 'LT'
        });
    });

    $(function () {
        $('#datetimepicker4').datetimepicker({
            format: 'LT'
        });
    });
  </script>
</body>

</html>
