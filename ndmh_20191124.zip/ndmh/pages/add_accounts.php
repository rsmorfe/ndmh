<?php session_start();

if($_SESSION['loggedIn'] != 'yes'){
header('Location:../index.php');}?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>NDMH | ADD ACCOUNTS</title>

  <!-- Custom fonts for this template-->
  <link href="../dist/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="../dist/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../dist/css/sb-admin.css" rel="stylesheet">

</head>
<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <a class="navbar-brand mr-1" href="dashboard.php">NDMH ADMIN PAGE</a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>


    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0">
      
    <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span>Welcome, &nbsp</span>
           <?php echo $_SESSION['member_first']; ?>&nbsp<?php echo $_SESSION['member_last']; ?> &nbsp [<?php echo $_SESSION['status']; ?>] &nbsp
          <i class="fas fa-user-circle"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
      </li>
    </ul>

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <!-- Main Transaction Forms -->
        <?php 
          include('menu_transaction.php');
        ?>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <!-- Viewing Forms -->
          <?php 
            include('menu_views.php');
          ?>
        </div>
      </li>
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            &nbspAdd Accounts
          </div>
          <div class="card-body">
          <?php 
  if(isset($_POST['member_first'])){

    $conn = mysqli_connect('localhost','root',''); //connect to the mysql server 
    mysqli_select_db($conn,'ndmh'); //select database to work with 
      
    $member_first   = mysqli_real_escape_string($conn,$_POST['member_first']); 
    $member_last = mysqli_real_escape_string($conn,$_POST['member_last']); 
    $member_rank   = mysqli_real_escape_string($conn,$_POST['member_rank']); 
    $dept_code = mysqli_real_escape_string($conn,$_POST['dept_code']);  
    $username   = mysqli_real_escape_string($conn,$_POST['username']); 
    $password = mysqli_real_escape_string($conn,$_POST['password']); 
    $status   = mysqli_real_escape_string($conn,$_POST['status']);     
    
    $sql        = "INSERT INTO member(member_first,member_last,member_rank,dept_code,username,password,status) VALUES('$member_first','$member_last','$member_rank','$dept_code','$username','$password','$status')";

    $execute = mysqli_query($conn,$sql);
    
    if(mysqli_errno($conn) > 0 ){
     echo "<script type='text/javascript'>alert('Error !!!');</script>";     
    }else{
      echo "<script type='text/javascript'>alert('Successfully Added!');</script>";
    }
  
  }
?>
  <form method="post">
    <h6>First Name</h6>
    <input class="form-control" type="text" name="member_first" required><br><br>

    <h6>Last name</h6>
    <input class="form-control" type="text" name="member_last" required><br><br>

    <h6>Rank</h6>
    <input class="form-control" type="text" name="member_rank" required><br><br>

    <h6>Dept Code</h6>
    <input class="form-control" type="text" name="dept_code" required><br><br>

    <h6>Username</h6>
    <input class="form-control" type="text" name="username" required><br><br>

    <h6>Password</h6>
    <input class="form-control" type="password" name="password" required><br><br>

    <h6>Access Type</h6>
    <input class="form-control" type="text" name="status" required><br><br>



    <input type="submit" value="ADD">
  </form>
  </center>
          </div>
        </div>
        

      </div>

        
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © New Divine Mercy Hospital - OPD 2019</span>
          </div>
        </div>
      </footer>

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript-->
  <script src="../dist/vendor/jquery/jquery.min.js"></script>
  <script src="../dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../dist/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts h6 all pages-->
  <script src="../dist/js/sb-admin.min.js"></script>

</body>

</html>
