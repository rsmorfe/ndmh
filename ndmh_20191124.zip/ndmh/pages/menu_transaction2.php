<a class="dropdown-item" href="add_patient2.php">Add Patient</a>
<a class="dropdown-item" href="add_roomschedule2.php">Add Schedule</a>