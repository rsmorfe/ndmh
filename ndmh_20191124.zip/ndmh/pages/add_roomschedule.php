<?php session_start();

include('../dist/includes/dbcon.php');

if($_SESSION['loggedIn'] != 'yes'){
header('Location:../index.php');}?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>NDMH | ADD ROOM SCHEDULE</title>

  <!-- Bootstrap CSS-->
  <link href="../dist/css/bootstrap.css" rel="stylesheet">

  <!-- Custom fonts for this template-->
  <link href="../dist/vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="../dist/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- DateTimePicker CSS-->
  <link href="../dist/css/bootstrap-datetimepicker.min.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../dist/css/sb-admin.css" rel="stylesheet">

</head>
<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <a class="navbar-brand mr-1" href="dashboard.php">NDMH ADMIN PAGE</a>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>


    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0">
      
    <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span>Welcome, &nbsp</span>
           <?php echo $_SESSION['member_first']; ?>&nbsp<?php echo $_SESSION['member_last']; ?> &nbsp [<?php echo $_SESSION['status']; ?>] &nbsp
          <i class="fas fa-user-circle"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
      </li>
    </ul>

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <!-- Main Transaction Forms -->
        <?php 
          include('menu_transaction.php');
        ?>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <!-- Viewing Forms -->
          <?php 
            include('menu_views.php');
          ?>
        </div>
      </li>
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            &nbspAdd Room Schedule
          </div>
          <div class="card-body">
          <?php 
  if(isset($_POST['add_roomsched'])){

    $conn = mysqli_connect('localhost','root',''); //connect to the mysql server 
    mysqli_select_db($conn,'ndmh'); //select database to work with 
      
    $sched_room   = mysqli_real_escape_string($conn,$_POST['sched_room']); 
    $sched_doctor = mysqli_real_escape_string($conn,$_POST['sched_doctor']); 
    $sched_days   = mysqli_real_escape_string($conn,$_POST['sched_days']); 
    $sched_time_from = mysqli_real_escape_string($conn,date( "H:i:s", strtotime($_POST['sched_time_from'])));  
    $sched_time_to   = mysqli_real_escape_string($conn,date( "H:i:s", strtotime($_POST['sched_time_to']))); 
    
    
    $sql = "INSERT INTO roomschedule(RoomID,DoctorID,ConsultationDays,ConsultationStart,ConsultationEnd) VALUES('$sched_room','$sched_doctor','$sched_days','$sched_time_from','$sched_time_to')";

    $execute = mysqli_query($conn,$sql);
    
    if(mysqli_errno($conn) > 0 ){
     echo "<script type='text/javascript'>alert('Error !!!');</script>";     
    }else{
      echo "<script type='text/javascript'>alert('Successfully Added!');</script>";
    }
  
  }
?>
  <form method="post">
    <h6>Room </h6>
    <input class="form-control" type="text" name="sched_room" autocomplete="off"><br>

    <h6>Doctor</h6>
    <select class="form-control" name="sched_doctor">
      <?php

        $sql = "SELECT dr_id,concat(first_name,' ',last_name) as DoctorName from doctors";
        $results = mysqli_query($conn, $sql);

        while($result = mysqli_fetch_assoc($results)){
      ?>
      <option value="<?php echo htmlentities($result['dr_id']);?>"><?php echo htmlentities($result["DoctorName"]);?></option>
    <?php } ?>
    </select><br>
    

    <h6>Consultation Days</h6>
    <input class="form-control" type="text" name="sched_days" autocomplete="off"><br>

    <h6>Consultation Time (From)</h6>
    <div class='input-group date' id='datetimepicker3' >
        <input type='text' class="form-control" name="sched_time_from"/>    
          <span class="input-group-addon btn btn-secondary">
              <span class="fa fa-clock"></span>
          </span>
    </div><br>

    <h6>Consultation Time (To)</h6>
  
    <div class='input-group date' id='datetimepicker4' >
      <input type='text' class="form-control" name="sched_time_to"/>    
        <span class="input-group-addon btn btn-secondary">
            <span class="fa fa-clock"></span>
        </span>
    </div><br>

    <input type="submit" value="ADD" name="add_roomsched">
  </form>

          </div>
        </div>
 

      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © New Divine Mercy Hospital - OPD 2019</span>
          </div>
        </div>
      </footer>


    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript-->
  <script src="../dist/vendor/jquery/jquery.js"></script>
  <script src="../dist/js/moment.js"></script>
  <script src="../dist/js/transition.js"></script>
  <script src="../dist/js/collapse.js"></script>
  <script src="../dist/vendor/jquery/jquery.min.js"></script>
  <script src="../dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../dist/vendor/bootstrap/js/bootstrap.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../dist/vendor/jquery-easing/jquery.easing.js"></script>

  <!-- Custom scripts h6 all pages-->
  <script src="../dist/js/sb-admin.min.js"></script>

  <!-- DateTimePicker-->
  <script src="../dist/js/bootstrap-datetimepicker.js"></script>
  
  
  
  <script type="text/javascript">
    $(function () {
        $('#datetimepicker3').datetimepicker({
            format: 'LT'
        });
    });

    $(function () {
        $('#datetimepicker4').datetimepicker({
            format: 'LT'
        });
    });
  </script>
</body>

</html>
