<?php session_start();
if(empty($_SESSION['id'])):
header('../index.php');
endif;

include('../dist/includes/dbcon.php'); 
mysqli_select_db($conn,'ndmh'); //select database to work with 

  $sql = "DELETE FROM queuelist_online where ol_id = ". $_GET["id"];
  $execute = mysqli_query($conn,$sql) or mysqli_errno($conn);
  echo "<script>document.location='scheduler_online.php'</script>"; 	
?>
