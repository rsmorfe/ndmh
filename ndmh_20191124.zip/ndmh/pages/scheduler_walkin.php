<?php session_start();

if($_SESSION['loggedIn'] != 'yes'){
header('Location:../index.php');}

include('../dist/includes/dbcon.php');

if (isset($_POST['first_name'])) {
  mysqli_select_db($conn,'ndmh'); //select database to work with 
      
    $first_name   = mysqli_real_escape_string($conn,$_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn,$_POST['last_name']);
    $concern   = mysqli_real_escape_string($conn,$_POST['concern']);
    $schedID   = mysqli_real_escape_string($conn,$_POST['scheduleID']);

    $sql= "INSERT INTO queuelist_win(fname,lname,concern,schedID) VALUES('$first_name','$last_name','$concern',$schedID)";

    $execute = mysqli_query($conn,$sql);
    if(mysqli_errno($conn) > 0 ){
     echo "<script type='text/javascript'>alert('Error !!!');</script>";     
    }else{
      echo "<script type='text/javascript'>alert('Successfully Added!');</script>";
      echo "<script>document.location='scheduler_walkin.php'</script>"; 
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>NDMH | Patient Scheduler - Walk In</title>

  <!-- Custom fonts for this template-->
  <link href="../dist/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="../dist/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../dist/css/sb-admin.css" rel="stylesheet">

</head>
<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <?php 
      if($_SESSION['status'] == 'administrator') {
        echo '<a class="navbar-brand mr-1" href="dashboard.php">NDMH ADMIN PAGE</a>';
      } elseif ($_SESSION['status'] == 'NurseStation') {
        echo '<a class="navbar-brand mr-1" href="nurse_view.php">NDMH PAGE</a>';
      } elseif ($_SESSION['status'] == 'Doctor') {
        echo '<a class="navbar-brand mr-1" href="doctor_view.php">NDMH PAGE</a>';
      }
    ?>

    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>


    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      
    </form>

    <!-- Navbar -->
    <ul class="navbar-nav ml-auto ml-md-0">
      
    <li class="nav-item dropdown no-arrow">
        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span>Welcome, &nbsp</span>
           <?php echo $_SESSION['member_first']; ?>&nbsp<?php echo $_SESSION['member_last']; ?> &nbsp [<?php echo $_SESSION['status']; ?>] &nbsp
          <i class="fas fa-user-circle"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
          <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
      </li>
    </ul>

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item">
        <?php
          if ($_SESSION['status'] == 'administrator') {
            echo '<a class="nav-link" href="dashboard.php">';
          } elseif ($_SESSION['status'] == 'NurseStation') {
            echo '<a class="nav-link" href="nurse_view.php">';
          } 
        ?>
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
      <?php
        if ($_SESSION['status'] == 'NurseStation') {
          echo '<li class="nav-item">';
          echo '<a class="nav-link" href="doctor_list2.php">';
          echo '<i class="fas fa-fw fa-user-alt"></i>';
          echo '<span> Doctors List</span></a></li>';
        } 
      ?>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-fw fa-folder"></i>
          <span>Pages</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
        <!-- Main Transaction Forms -->
        <?php 
          if ($_SESSION['status'] == 'administrator') {
            include('menu_transaction.php');
          } elseif ($_SESSION['status'] == 'NurseStation') {
            include('menu_transaction2.php');
          } 
        ?>
          <div class="dropdown-divider"></div>
          <h6 class="dropdown-header">Other Pages:</h6>
          <!-- Viewing Forms -->
          <?php 
            if($_SESSION['status'] == 'administrator') {
              include('menu_views.php');
            } elseif ($_SESSION['status'] == 'NurseStation') {
              include('menu_views2.php');
            } 
          ?>
        </div>
      </li>
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-table"></i>
            Patient Scheduler (Walk-In)             
            </div>
          <div class="card-body">
            <form method="post">
              <h6>First Name</h6>
              <input class="form-control" type="text" name="first_name" required><br>

              <h6>Last Name</h6>
              <input class="form-control" type="text" name="last_name" required><br>

              <h6>Concern</h6>
              <input class="form-control" type="text" name="concern" required><br>
              
              <h6>Select Schedule</h6>
              <select class="form-control" name="scheduleID"  autocomplete="off" required>
              <?php
                if (!$conn) {
                  die("Connection failed: " . mysqli_connect_error());
                }

                $sql = "SELECT id,(select specialty from doctors where dr_id = DoctorID) as Specialty,(select concat(first_name,' ',last_name) from doctors where dr_id = DoctorID) as Doctor,concat(ConsultationStart,' - ',ConsultationEnd) as Schedule FROM roomschedule";
                $results = mysqli_query($conn, $sql);
    
                while($result = mysqli_fetch_assoc($results)){  //fetching the result (iteration)
                  echo '<option value='.$result[id].'>['.$result[Specialty].'] - '.$result[Doctor].' ('.$result[Schedule].')'.'</option>';
                }             
              ?>
            </select><br>

              <input type="submit" value="ADD">
            </form>
          </div>
          <hr/>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <?php 
                  
              
                if (!$conn) {
                  die("Connection failed: " . mysqli_connect_error());
                }

                $sql = "SELECT wid,fname,lname,concern,DateCreated FROM queuelist_win where DATE(DateCreated) = DATE(NOW())";
                $results = mysqli_query($conn, $sql);
                  
                if(!$results){ //if the query return a row
                  //no record found
                  echo "Record Not Found"; 
      
                }elseif(mysqli_num_rows($results) > 0){ //if the query return a row
                  echo "<thead> <tr><th>ID</th><th>First Name</th><th>Last Name</th><th>concern</th><th>Date</th><th>Action</th></tr>"; //record found
                  while($result = mysqli_fetch_assoc($results)){  //fetching the result (iteration)
                    echo '<tr><td>'. $result['wid']. '</td><td>' . $result['fname']. '</td><td>' . $result['lname'].'</td><td>' . $result['concern'].'</td><td>' . $result['DateCreated'].'</td>';
                    echo "<td><center><a class='btn btn-info' href='addsched_win.php?id=".$result['wid']."'>Add to List</a>&nbsp<a class='btn btn-danger' href='delsched_win.php?id=".$result['wid']."'>Delete</a><center></td>";
                    echo'</tr>';
                  }
                }else{
                  echo "No record/s found";
                }
              ?>
</table>    
    </div>    
      </div>
          </div>

      </div>

        
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © New Divine Mercy Hospital - OPD 2019</span>
          </div>
        </div>
      </footer>

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript-->
  <script src="../dist/vendor/jquery/jquery.min.js"></script>
  <script src="../dist/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../dist/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Datatable Script-->
  <script src="../dist/vendor/datatables/jquery.dataTables.js"></script>
  <script src="../dist/vendor/datatables/dataTables.bootstrap4.js"></script>    

  <!-- Custom scripts for all pages-->
  <script src="../dist/js/sb-admin.min.js"></script>

</body>

</html>
