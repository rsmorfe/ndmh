<?php session_start();
if(empty($_SESSION['id'])):
header('../index.php');
endif;

	$conn = mysqli_connect('localhost','root',''); //connect to the mysql server 
	mysqli_select_db($conn,'ndmh');

	$member_id 		= $_POST['id'];
	$member_first   = $_POST['member_first'];    
    $member_last 	= $_POST['member_last']; 
    $member_rank   	= $_POST['member_rank'];      
    $dept_code 		= $_POST['dept_code']; 
    $username   	= $_POST['username'];   
    $password 		= $_POST['password'];
    $status   		= $_POST['status'];   
	
	mysqli_query($conn,"UPDATE member SET member_first='$member_first',member_last='$member_last',member_rank='$member_rank',dept_code='$dept_code',username='$username',password='$password',status='$status' WHERE member_id='$member_id'")or die(mysqli_error());
	
	echo "<script type='text/javascript'>alert('Successfully updated member details!');</script>";

	echo "<script>document.location='accounts.php'</script>";

	
?>
