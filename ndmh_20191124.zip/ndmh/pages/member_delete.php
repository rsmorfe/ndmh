<?php session_start();

if($_SESSION['loggedIn'] != 'yes'){
header('Location:../index.php');}

include("../dist/includes/dbcon.php");
$id=$_REQUEST['id'];
$result = mysqli_query($conn,"DELETE FROM member WHERE member_id ='$id'") or die(mysqli_error($conn));
	echo "<script type='text/javascript'>alert('Successfully deleted!');</script>";	
	echo "<script>document.location='accounts.php'</script>";  
?>