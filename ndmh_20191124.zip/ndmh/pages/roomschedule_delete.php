<?php session_start();

if($_SESSION['loggedIn'] != 'yes'){
header('Location:../index.php');}

include("../dist/includes/dbcon.php");
$id=$_REQUEST['id'];
$result = mysqli_query($conn,"DELETE FROM roomschedule WHERE id ='$id'") or die(mysqli_error($conn));
	echo "<script type='text/javascript'>alert('Successfully deleted!');</script>";	
	if ($_SESSION['status'] == 'administrator') {
		echo "<script>document.location='view_roomschedule.php'</script>";  
	} elseif ($_SESSION['status'] == 'NurseStation') {
		echo "<script>document.location='view_roomschedule2.php'</script>";  
	} 
	
?>