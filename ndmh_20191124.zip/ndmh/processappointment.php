<?php session_start();
if(empty($_SESSION['id'])):
header('../index.php');
endif;

include('dist/includes/dbcon.php'); 
mysqli_select_db($conn,'ndmh'); //select database to work with 

if(isset($_POST['accept_terms'])) {

  $sql = "SELECT count(ol_id) as CountRow FROM queuelist_online";
  $results = mysqli_query($conn, $sql);
  $rowCount = mysqli_fetch_assoc($results);
  if($rowCount['CountRow'] == 30){ 
    echo "<script type='text/javascript'>alert('Unable to Process at the moment. Slots for Online Appointment are full.');</script>";
    echo "<script>document.location='onlineappointment.php'</script>"; 
  }else{
    $first_name  = mysqli_real_escape_string($conn,$_POST['online_fname']);
    $last_name = mysqli_real_escape_string($conn,$_POST['online_lname']);
    $concern   = mysqli_real_escape_string($conn,$_POST['online_concern']);
    $schedule   = mysqli_real_escape_string($conn,$_POST['online_schedule']);
    $appointmentdate   = mysqli_real_escape_string($conn,date_format(date_create($_POST['appointment_date']),'Y-m-d'));
    //$appointmentdate   = mysqli_real_escape_string($conn,date("Y-m-d",strtotime($_POST['appointment_date'])));

    $sql= "INSERT INTO queuelist_online(fname,lname,concern,schedID,AppointmentDate) VALUES('$first_name','$last_name','$concern','$schedule','$appointmentdate')";

    $execute = mysqli_query($conn,$sql);
    if(mysqli_errno($conn) > 0 ){
      echo "<script type='text/javascript'>alert('Error !!!');</script>";     
    }else{
      //echo "<script type='text/javascript'>alert('".$appointmentdate."');</script>";    
      echo "<script type='text/javascript'>alert('Successfully Added!');</script>";
      echo "<script>document.location='onlineappointment.php'</script>"; 
    }
  
  
  } 
}


	
?>
