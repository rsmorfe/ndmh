<?php session_start();
if($_SESSION['loggedIn'] != 'yes'){
  header('Location:index.php');}

include('dist/includes/dbcon.php');

if(isset($_POST['login']))
{

$user_unsafe=$_POST['username'];
$pass_unsafe=$_POST['password'];

$user = mysqli_real_escape_string($conn,$user_unsafe);
$pass = mysqli_real_escape_string($conn,$pass_unsafe);


$query=mysqli_query($conn,"select * from member where username='$user' and password='$pass'")or die(mysqli_error($conn));
  $row=mysqli_fetch_array($query);
           
           $counter=mysqli_num_rows($query);
           $_SESSION['member_first']=$row['member_first'];
           $_SESSION['member_last']=$row['member_last'];
           $_SESSION['status']=$row['status'];
           $id=$row['member_id'];
           $status=$row['status'];
      if ($counter == 0) 
      { 
      echo "<script type='text/javascript'>alert('Invalid Username or Password!');
      document.location='index.php'</script>";
      } 
    else
      {
       
        $_SESSION['loggedIn'] = 'yes';

        if ($status=='administrator') {
          header('location:pages/dashboard.php');
         }
        elseif ($status=='NurseStation') {
          header('location:pages/nurse_view.php');
        }
        elseif ($status=='Doctor') {
          header('location:pages/doctor_view.php');
        }
        else
        {
          header('location:pages/404.php');
        }

    }
}  
?>